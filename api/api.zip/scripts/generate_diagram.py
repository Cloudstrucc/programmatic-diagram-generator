#!/usr/bin/env python3
"""
CloudStrucc Diagram Generator - Multi-Cloud Support with Valid Classes
"""

import argparse
import json
import sys
import os
import base64
import re
from pathlib import Path
import anthropic
from dotenv import load_dotenv

load_dotenv()

# Whitelist of VALID classes for each cloud provider
VALID_CLASSES = {
    'azure': {
        'compute': ['VM', 'AppServices', 'ContainerInstances', 'FunctionApps', 'AKS'],
        'network': ['VirtualNetworks', 'ApplicationGateway', 'Firewall', 'VPN', 'LoadBalancer', 'DNS'],
        'database': ['SQLDatabases', 'CosmosDb', 'DatabaseForMysql', 'DatabaseForPostgresql'],
        'storage': ['StorageAccounts', 'BlobStorage', 'DiskStorage'],
        'web': ['AppServices', 'APIManagement'],
        'security': ['KeyVault'],
    },
    'aws': {
        'compute': ['EC2', 'Lambda', 'ECS', 'EKS', 'Batch'],
        'network': ['VPC', 'ELB', 'CloudFront', 'Route53', 'APIGateway'],
        'database': ['RDS', 'DynamoDB', 'Aurora', 'Redshift'],
        'storage': ['S3', 'EBS', 'EFS', 'Glacier'],
        'security': ['IAM', 'SecretsManager', 'KMS'],
    },
    'gcp': {
        'compute': ['ComputeEngine', 'GKE', 'Functions', 'Run'],
        'network': ['VPC', 'LoadBalancing', 'DNS', 'CDN'],
        'database': ['SQL', 'Firestore', 'BigTable', 'Spanner'],
        'storage': ['GCS', 'PersistentDisk'],
        'analytics': ['BigQuery', 'Dataflow', 'Pubsub'],
    },
    'k8s': {
        'compute': ['Pod', 'Deployment', 'StatefulSet', 'DaemonSet'],
        'network': ['Service', 'Ingress'],
        'storage': ['PersistentVolume', 'PersistentVolumeClaim', 'StorageClass'],
    },
    'generic': {
        'compute': ['Rack'],
        'database': ['SQL'],
        'network': ['Router', 'Switch', 'Firewall'],
        'storage': ['Storage'],
    }
}

def get_class_list_for_prompt(style):
    """Generate formatted class list for Claude prompt"""
    if style not in VALID_CLASSES:
        style = 'generic'
    
    classes = VALID_CLASSES[style]
    class_text = ""
    
    for module, class_names in classes.items():
        class_text += f"\nfrom diagrams.{style}.{module} import {', '.join(class_names)}"
    
    return class_text

def generate_diagram_code(prompt, style, quality):
    """Generate Python code with Claude using validated classes"""
    client = anthropic.Anthropic(api_key=os.getenv('ANTHROPIC_API_KEY'))
    
    complexity_map = {
        'simple': '5-8 nodes',
        'standard': '8-15 nodes', 
        'enterprise': '15-25 nodes'
    }
    
    complexity = complexity_map.get(quality, '8-15 nodes')
    
    # Get valid classes for this style
    class_imports = get_class_list_for_prompt(style)
    
    provider_names = {
        'azure': 'Azure',
        'aws': 'AWS',
        'gcp': 'Google Cloud Platform',
        'k8s': 'Kubernetes',
        'generic': 'Generic/On-Premise'
    }
    
    provider = provider_names.get(style, 'Generic')
    
    system_prompt = f"""Generate a {provider} architecture diagram using the 'diagrams' library.

CRITICAL - Use ONLY these EXACT classes (no others):
{class_imports}

Also available:
- from diagrams.onprem.network import Internet
- from diagrams.onprem.client import User, Users

Requirements:
- Target complexity: {complexity} nodes
- Use realistic architecture patterns
- Include proper Cluster() groupings for logical separation
- Connect components with >> operator or Edge()
- Set graph_attr={{"bgcolor": "white", "pad": "0.5", "dpi": "150"}}
- Use show=False
- DO NOT include filename parameter
- Output ONLY Python code, no explanations

If you need a class that's not in the list, use the closest available alternative or a generic class."""

    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        messages=[{"role": "user", "content": f"Generate a {provider} architecture diagram for: {prompt}"}],
        system=system_prompt
    )
    
    code = message.content[0].text
    if '```python' in code:
        code = code.split('```python')[1].split('```')[0].strip()
    elif '```' in code:
        code = code.split('```')[1].split('```')[0].strip()
    
    return code

def execute_diagram_code(code, output_path):
    """Execute diagram code with dynamic imports"""
    exec_globals = {'__builtins__': __builtins__}
    
    try:
        from diagrams import Diagram, Cluster, Edge
        exec_globals.update({'Diagram': Diagram, 'Cluster': Cluster, 'Edge': Edge})
        
        # Import modules based on what's in the code
        if 'diagrams.azure' in code:
            from diagrams.azure import compute, network, database, storage, web, security
        if 'diagrams.aws' in code:
            from diagrams.aws import compute, network, database, storage, security
        if 'diagrams.gcp' in code:
            from diagrams.gcp import compute, network, database, storage, analytics
        if 'diagrams.k8s' in code:
            from diagrams.k8s import compute, network, storage
        
        # Always import generic and onprem
        from diagrams.generic import compute as gen_compute, network as gen_network, database as gen_database, storage as gen_storage
        from diagrams.onprem import network as onprem_network, client as onprem_client
        
        print(f"DEBUG: Executing code:\n{code}\n", file=sys.stderr)
        exec(code, exec_globals)
        print(f"DEBUG: Execution complete", file=sys.stderr)
        return True
        
    except Exception as e:
        print(f"DEBUG: Execution error: {e}", file=sys.stderr)
        raise Exception(f"Execution failed: {str(e)}")

def generate_diagram(prompt, style, diagram_type, quality, request_id):
    """Main generation with fallback to generic on failure"""
    try:
        print(f"Generating {style} diagram...", file=sys.stderr)
        code = generate_diagram_code(prompt, style, quality)
        
        script_dir = Path(__file__).parent.parent
        output_dir = script_dir / "diagrams"
        output_dir.mkdir(exist_ok=True)
        output_path = output_dir / request_id
        
        print(f"DEBUG: Original code:\n{code}\n", file=sys.stderr)
        
        # Inject filename
        code = re.sub(
            r'with\s+Diagram\s*\(\s*(["\'][^"\']+["\'])',
            rf'with Diagram(\1, filename="{output_path}"',
            code,
            count=1
        )
        
        print(f"DEBUG: After filename injection:\n{code}\n", file=sys.stderr)
        
        try:
            print("Executing code...", file=sys.stderr)
            execute_diagram_code(code, str(output_path))
        except Exception as exec_error:
            # Fallback to generic on execution failure
            print(f"Cloud-specific failed: {exec_error}, retrying with generic...", file=sys.stderr)
            code = generate_diagram_code(prompt, 'generic', quality)
            code = re.sub(
                r'with\s+Diagram\s*\(\s*(["\'][^"\']+["\'])',
                rf'with Diagram(\1, filename="{output_path}"',
                code,
                count=1
            )
            execute_diagram_code(code, str(output_path))
        
        # Read generated image
        image_file = f"{output_path}.png"
        print(f"DEBUG: Looking for: {image_file}", file=sys.stderr)
        
        if not os.path.exists(image_file):
            raise Exception(f"Image not created: {image_file}")
        
        print(f"DEBUG: Image found! Size: {os.path.getsize(image_file)} bytes", file=sys.stderr)
        
        with open(image_file, 'rb') as f:
            image_data = base64.b64encode(f.read()).decode('utf-8')
        
        return {
            'success': True,
            'imageData': image_data,
            'xmlData': None,
            'metadata': {
                'prompt': prompt,
                'style': style,
                'type': diagram_type,
                'quality': quality,
                'nodeCount': 'Generated'
            }
        }
        
    except Exception as e:
        print(f"DEBUG: Error in generate_diagram: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            'success': False,
            'error': str(e),
            'imageData': None,
            'xmlData': None,
            'metadata': None
        }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prompt', required=True)
    parser.add_argument('--style', required=True, choices=['azure', 'aws', 'gcp', 'k8s', 'generic'])
    parser.add_argument('--type', required=True, choices=['python', 'drawio'])
    parser.add_argument('--quality', required=True, choices=['simple', 'standard', 'enterprise'])
    parser.add_argument('--request-id', required=True)
    
    args = parser.parse_args()
    
    if not os.getenv('ANTHROPIC_API_KEY'):
        print(json.dumps({'success': False, 'error': 'ANTHROPIC_API_KEY not set'}))
        sys.exit(1)
    
    result = generate_diagram(args.prompt, args.style, args.type, args.quality, args.request_id)
    print(json.dumps(result))
    
    if not result['success']:
        sys.exit(1)

if __name__ == '__main__':
    main()