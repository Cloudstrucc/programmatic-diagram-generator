// config.js - Configuration for Diagram Generator API
require('dotenv').config();

module.exports = {
  // Anthropic API Configuration
  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY,
    model: 'claude-sonnet-4-5-20250929',
    apiVersion: '2023-06-01',
    baseURL: 'https://api.anthropic.com/v1/messages'
  },

  // Rate Limiting Configuration (adjust based on your 5x or 20x plan)
  rateLimits: {
    // For 20x plan with Sonnet 4.5
    requestsPerMinute: 100,
    tokensPerMinute: 800000,
    requestsPerDay: 100000,
    tokensPerDay: 50000000,
    
    // Per-user limits for subscription tiers
    tiers: {
      free: {
        requestsPerDay: 10,
        requestsPerHour: 5,
        maxConcurrent: 1
      },
      basic: {
        requestsPerDay: 100,
        requestsPerHour: 20,
        maxConcurrent: 2
      },
      pro: {
        requestsPerDay: 500,
        requestsPerHour: 100,
        maxConcurrent: 5
      },
      enterprise: {
        requestsPerDay: 5000,
        requestsPerHour: 1000,
        maxConcurrent: 20
      }
    }
  },

  // Queue Configuration
  queue: {
    maxQueueSize: 1000,
    processingInterval: 1000, // Process queue every second
    retryAttempts: 3,
    retryDelay: 2000, // 2 seconds
    requestTimeout: 120000 // 2 minutes
  },

  // Database Configuration (use your preferred DB)
  database: {
    type: process.env.DB_TYPE || 'mongodb', // or 'postgresql', 'mysql'
    connectionString: process.env.DATABASE_URL,
    usageCollection: 'api_usage',
    queueCollection: 'request_queue'
  },

  // Redis Configuration (for distributed systems)
  redis: {
    enabled: process.env.REDIS_ENABLED === 'true',
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD
  },

  // Server Configuration
  server: {
    port: process.env.PORT || 3000,
    corsOrigins: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000']
  }
};
