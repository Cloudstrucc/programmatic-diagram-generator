// middleware/auth.js - Authentication and authorization middleware
const jwt = require('jsonwebtoken');

/**
 * Verify JWT token and attach user to request
 */
async function authenticate(req, res, next) {
  try {
    // Get token from header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'No token provided'
      });
    }

    const token = authHeader.substring(7);

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Get user from database
    const user = await req.app.locals.db.collection('users').findOne({ 
      _id: decoded.userId 
    });

    if (!user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Invalid token'
      });
    }

    // Check if user is active
    if (user.status !== 'active') {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: 'Account is not active'
      });
    }

    // Attach user to request
    req.user = {
      id: user._id.toString(),
      email: user.email,
      tier: user.subscriptionTier || 'free',
      isAdmin: user.role === 'admin'
    };

    next();

  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: 'TOKEN_EXPIRED',
        message: 'Token has expired'
      });
    }

    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        error: 'INVALID_TOKEN',
        message: 'Invalid token'
      });
    }

    console.error('Auth error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Authentication failed'
    });
  }
}

/**
 * API Key authentication (alternative to JWT)
 */
async function authenticateApiKey(req, res, next) {
  try {
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'No API key provided'
      });
    }

    // Hash the API key (you should store hashed keys in DB)
    const crypto = require('crypto');
    const hashedKey = crypto.createHash('sha256').update(apiKey).digest('hex');

    // Look up API key in database
    const keyRecord = await req.app.locals.db.collection('api_keys').findOne({
      keyHash: hashedKey,
      active: true
    });

    if (!keyRecord) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Invalid API key'
      });
    }

    // Check expiration
    if (keyRecord.expiresAt && keyRecord.expiresAt < new Date()) {
      return res.status(401).json({
        error: 'API_KEY_EXPIRED',
        message: 'API key has expired'
      });
    }

    // Get user associated with API key
    const user = await req.app.locals.db.collection('users').findOne({
      _id: keyRecord.userId
    });

    if (!user || user.status !== 'active') {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: 'Account is not active'
      });
    }

    // Update last used timestamp
    await req.app.locals.db.collection('api_keys').updateOne(
      { _id: keyRecord._id },
      { 
        $set: { lastUsedAt: new Date() },
        $inc: { usageCount: 1 }
      }
    );

    // Attach user to request
    req.user = {
      id: user._id.toString(),
      email: user.email,
      tier: user.subscriptionTier || 'free',
      isAdmin: user.role === 'admin',
      apiKeyId: keyRecord._id.toString()
    };

    next();

  } catch (error) {
    console.error('API key auth error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Authentication failed'
    });
  }
}

/**
 * Rate limiting middleware (basic implementation)
 */
const rateLimitCache = new Map();

function rateLimit(windowMs = 60000, maxRequests = 100) {
  return (req, res, next) => {
    const identifier = req.user?.id || req.ip;
    const now = Date.now();
    const windowKey = `${identifier}-${Math.floor(now / windowMs)}`;

    const current = rateLimitCache.get(windowKey) || 0;

    if (current >= maxRequests) {
      return res.status(429).json({
        error: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests',
        retryAfter: Math.ceil((windowMs - (now % windowMs)) / 1000)
      });
    }

    rateLimitCache.set(windowKey, current + 1);

    // Clean up old entries
    if (Math.random() < 0.01) { // 1% chance to clean up
      const cutoff = Math.floor((now - windowMs * 2) / windowMs);
      for (const key of rateLimitCache.keys()) {
        const timestamp = parseInt(key.split('-').pop());
        if (timestamp < cutoff) {
          rateLimitCache.delete(key);
        }
      }
    }

    next();
  };
}

/**
 * Require specific subscription tier
 */
function requireTier(minimumTier) {
  const tierLevels = {
    free: 0,
    basic: 1,
    pro: 2,
    enterprise: 3
  };

  return (req, res, next) => {
    const userTierLevel = tierLevels[req.user.tier] || 0;
    const requiredLevel = tierLevels[minimumTier] || 0;

    if (userTierLevel < requiredLevel) {
      return res.status(403).json({
        error: 'TIER_REQUIRED',
        message: `${minimumTier} tier or higher required`,
        currentTier: req.user.tier,
        requiredTier: minimumTier
      });
    }

    next();
  };
}

/**
 * CORS middleware
 */
function cors(req, res, next) {
  const allowedOrigins = process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000'];
  const origin = req.headers.origin;

  if (allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }

  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
  res.setHeader('Access-Control-Max-Age', '86400');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  next();
}

module.exports = {
  authenticate,
  authenticateApiKey,
  rateLimit,
  requireTier,
  cors
};
