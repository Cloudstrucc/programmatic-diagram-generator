// routes/diagram.js - Updated with draw.io template support
const express = require('express');
const router = express.Router();

/**
 * GET /api/diagram/templates
 * List available diagram templates
 */
router.get('/templates', async (req, res) => {
  try {
    const drawioEngine = req.app.locals.drawioEngine;
    const templates = drawioEngine.getAvailableTemplates();

    res.json({
      success: true,
      templates: templates,
      supported: {
        cloud: ['aws', 'azure', 'gcp'],
        containers: ['kubernetes'],
        infrastructure: ['network', 'infrastructure'],
        modeling: ['flowchart', 'uml']
      }
    });

  } catch (error) {
    console.error('Get templates error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to retrieve templates'
    });
  }
});

/**
 * GET /api/diagram/templates/:type
 * Get detailed information about a specific template
 */
router.get('/templates/:type', async (req, res) => {
  try {
    const { type } = req.params;
    const drawioEngine = req.app.locals.drawioEngine;

    const details = drawioEngine.getTemplateDetails(type);

    res.json({
      success: true,
      template: details.template,
      style: details.style,
      shapes: details.shapes,
      stencils: details.stencils
    });

  } catch (error) {
    if (error.message.includes('Unknown template')) {
      return res.status(404).json({
        error: 'TEMPLATE_NOT_FOUND',
        message: error.message
      });
    }

    console.error('Get template details error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to retrieve template details'
    });
  }
});

/**
 * POST /api/diagram/generate
 * Generate a diagram (supports both Mermaid and draw.io)
 */
router.post('/generate', async (req, res) => {
  try {
    const { prompt, diagramType, templateType, styleOptions, options } = req.body;
    const userId = req.user.id;
    const userTier = req.user.tier || 'free';

    // Validate request
    if (!prompt) {
      return res.status(400).json({
        error: 'INVALID_REQUEST',
        message: 'Prompt is required'
      });
    }

    // Default to mermaid if not specified
    const finalDiagramType = diagramType || 'mermaid';

    // Prepare prompt based on diagram type
    let finalPrompt = prompt;
    
    if (finalDiagramType === 'drawio' && templateType) {
      // Use draw.io template engine
      const drawioEngine = req.app.locals.drawioEngine;
      finalPrompt = drawioEngine.generateDrawioPrompt(prompt, templateType, styleOptions);
    }

    // Enqueue request
    const queueResult = await req.app.locals.queueManager.enqueue({
      userId,
      userTier,
      prompt: finalPrompt,
      options: {
        diagramType: finalDiagramType,
        templateType: templateType || null,
        styleOptions: styleOptions || {},
        maxTokens: options?.maxTokens || 4096,
        temperature: options?.temperature || 1.0,
        ...options
      }
    });

    res.status(202).json({
      success: true,
      requestId: queueResult.requestId,
      status: 'queued',
      diagramType: finalDiagramType,
      templateType: templateType || null,
      position: queueResult.position,
      estimatedWait: queueResult.estimatedWait,
      statusUrl: `/api/diagram/status/${queueResult.requestId}`
    });

  } catch (error) {
    if (error.code === 'USER_LIMIT_EXCEEDED') {
      return res.status(429).json({
        error: error.code,
        message: error.message,
        details: error.details,
        retryAfter: error.details.resetTime
      });
    }

    if (error.code === 'CONCURRENT_LIMIT_EXCEEDED') {
      return res.status(429).json({
        error: error.code,
        message: error.message,
        currentActive: error.currentActive
      });
    }

    if (error.code === 'QUEUE_FULL') {
      return res.status(503).json({
        error: error.code,
        message: error.message,
        queueSize: error.queueSize
      });
    }

    console.error('Generate diagram error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to process request'
    });
  }
});

/**
 * GET /api/diagram/status/:requestId
 * Check status of a diagram generation request
 */
router.get('/status/:requestId', async (req, res) => {
  try {
    const { requestId } = req.params;
    const userId = req.user.id;

    const status = await req.app.locals.queueManager.getRequestStatus(requestId);

    if (!status) {
      return res.status(404).json({
        error: 'NOT_FOUND',
        message: 'Request not found'
      });
    }

    // Security: Only allow user to see their own requests
    const dbItem = await req.app.locals.db.collection(req.app.locals.config.database.queueCollection)
      .findOne({ requestId, userId });

    if (!dbItem) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: 'Not authorized to view this request'
      });
    }

    // Post-process draw.io results if needed
    let result = status.result;
    if (status.status === 'completed' && dbItem.options?.diagramType === 'drawio' && result) {
      const drawioEngine = req.app.locals.drawioEngine;
      const validation = drawioEngine.validateDrawioXML(result);
      
      if (!validation.valid) {
        console.error('Invalid draw.io XML:', validation.error);
        // Try to extract XML from markdown code blocks if Claude wrapped it
        const xmlMatch = result.match(/```(?:xml)?\s*\n?([\s\S]*?)\n?```/);
        if (xmlMatch) {
          result = xmlMatch[1].trim();
        }
      }

      // Post-process to ensure quality
      if (dbItem.options?.templateType) {
        result = drawioEngine.postProcessDrawioXML(result, dbItem.options.templateType);
      }
    }

    res.json({
      requestId,
      status: status.status,
      position: status.position,
      result: result,
      error: status.error,
      completedAt: status.completedAt,
      tokensUsed: status.tokensUsed,
      diagramType: dbItem.options?.diagramType,
      templateType: dbItem.options?.templateType
    });

  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to retrieve status'
    });
  }
});

/**
 * DELETE /api/diagram/cancel/:requestId
 * Cancel a queued request
 */
router.delete('/cancel/:requestId', async (req, res) => {
  try {
    const { requestId } = req.params;
    const userId = req.user.id;

    const cancelled = await req.app.locals.queueManager.cancelRequest(requestId, userId);

    if (!cancelled) {
      return res.status(404).json({
        error: 'NOT_FOUND',
        message: 'Request not found or already processed'
      });
    }

    res.json({
      success: true,
      message: 'Request cancelled successfully'
    });

  } catch (error) {
    console.error('Cancel request error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to cancel request'
    });
  }
});

/**
 * GET /api/diagram/usage
 * Get usage statistics for current user
 */
router.get('/usage', async (req, res) => {
  try {
    const userId = req.user.id;
    const { timeWindow = 'day' } = req.query;

    const usage = await req.app.locals.usageTracker.getUserUsage(userId, timeWindow);

    res.json({
      timeWindow,
      usage: {
        requests: usage.totalRequests,
        tokens: usage.totalTokens,
        estimatedCost: usage.totalCost
      }
    });

  } catch (error) {
    console.error('Usage check error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to retrieve usage'
    });
  }
});

/**
 * GET /api/diagram/queue/status
 * Get current queue status (admin only)
 */
router.get('/queue/status', requireAdmin, async (req, res) => {
  try {
    const status = req.app.locals.queueManager.getQueueStatus();
    res.json(status);
  } catch (error) {
    console.error('Queue status error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to retrieve queue status'
    });
  }
});

/**
 * GET /api/diagram/stats
 * Get usage statistics (admin only)
 */
router.get('/stats', requireAdmin, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 86400000);
    const end = endDate ? new Date(endDate) : new Date();

    const stats = await req.app.locals.usageTracker.getUsageStats(start, end);

    res.json({
      startDate: start,
      endDate: end,
      stats
    });

  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to retrieve statistics'
    });
  }
});

/**
 * POST /api/diagram/validate/drawio
 * Validate draw.io XML (useful for testing)
 */
router.post('/validate/drawio', async (req, res) => {
  try {
    const { xml } = req.body;

    if (!xml) {
      return res.status(400).json({
        error: 'INVALID_REQUEST',
        message: 'XML content is required'
      });
    }

    const drawioEngine = req.app.locals.drawioEngine;
    const validation = drawioEngine.validateDrawioXML(xml);

    res.json({
      valid: validation.valid,
      error: validation.error || null
    });

  } catch (error) {
    console.error('Validation error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Failed to validate XML'
    });
  }
});

/**
 * Middleware to require admin access
 */
function requireAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({
      error: 'FORBIDDEN',
      message: 'Admin access required'
    });
  }
  next();
}

module.exports = router;
